package com.javaproyect.proyect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectApplicationTests {

	@Test
	void contextLoads() {
	}

}
